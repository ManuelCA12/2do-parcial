// a) Cambia el contenido (el innerHTML) del elemento <p> con id="demo"
document.getElementById("demo").innerHTML = "¡Hola Mundo!";
console.log("Contenido del elemento con id 'demo' cambiado a: ¡Hola Mundo!");

// b) Encuentra el elemento con id="intro"
const introElemento = document.getElementById("intro");
console.log("Elemento con id 'intro' encontrado:", introElemento);

// Encuentra todos los elementos <p> de uno de tus proyectos .html
const todosLosParrafos = document.getElementsByTagName("p");
console.log("Todos los elementos <p> encontrados:", todosLosParrafos);

// b) Encuentra el elemento con id="main" y luego encuentra todos los elementos <p> dentro del main
const main = document.getElementById("main");
const parrafosEnMain = main.getElementsByTagName("p");
console.log("Elementos <p> dentro del elemento con id 'main':", parrafosEnMain);

// Encuentra todos los elementos con el mismo nombre de clase
const elementosIntro = document.getElementsByClassName("intro");
console.log("Elementos con la clase 'intro' encontrados:", elementosIntro);

// Devuelve una lista de todos los elementos <p> con class="intro"
const parrafosIntro = document.querySelectorAll("p.intro");
console.log("Elementos <p> con la clase 'intro' encontrados:", parrafosIntro);

// Encuentra los elementos <li> hijos de <ul>
const elementosLi = document.querySelectorAll("ul > li");
console.log("Elementos <li> hijos de <ul> encontrados:", elementosLi);

// Encontrar en la consola e imprimir el elemento <h1>
const elementoH1 = document.querySelector("h1");
console.log("Elemento <h1> encontrado:", elementoH1);

// Encontrar la clase list usando querySelector()
const elementoList = document.querySelector(".list");
console.log("Elemento con la clase 'list' encontrado:", elementoList);

// Imprimir los elementos <li> haciendo uso del ciclo forEach() para iterar sobre la NodeList e imprimir cada uno de los elementos
const listaDeElementos = document.querySelectorAll("ul > li");
listaDeElementos.forEach((item) => {
  console.log("Elemento <li> encontrado:", item);
});

// a) Encuentra el elemento de formulario con id="frm1", en la colección de formularios, y muestra todos los valores de los elementos
function mostrarValoresFormulario() {
  const formulario = document.forms["frm1"];
  let texto = "";
  for (let i = 0; i < formulario.length; i++) {
    texto += formulario.elements[i].value + "<br>";
  }
  document.getElementById("demoForm").innerHTML = texto;
  console.log("Valores del formulario mostrados:", texto);
}

// a) Agregar elementos al árbol del DOM usando los métodos document.createElement(), appendChild() y haciendo uso de la propiedad textContent
function agregarElementos() {
  let contenedor = document.getElementById("contenedorElementos");

  let lista = document.createElement("ul");
  contenedor.appendChild(lista);

  let elemento1 = document.createElement("li");
  elemento1.textContent = "Mar";
  lista.appendChild(elemento1);

  let elemento2 = document.createElement("li");
  elemento2.textContent = "Mono";
  lista.appendChild(elemento2);

  console.log("Nuevos elementos agregados al DOM en contenedor específico:", lista);
}

// a) Usando el método addEventListener() para escuchar eventos en la página
const button = document.getElementById("btn");
button.addEventListener("click", () => {
  alert("GRACIAS POR DAR CLICK");
  console.log("Evento de click en el botón registrado.");
});

// a) Si un campo de formulario (name) esta vacío, se muestra una alerta con un mensaje y devuelve falso para evitar que se envíe y se redireccione a otra página
function validarFormulario() {
  let x = document.forms["miFormulario"]["nombre"].value;
  if (x === "") {
    alert("Debe completar el nombre");
    console.log("Validación fallida: campo 'nombre' vacío.");
    return false;
  }
  console.log("Formulario validado correctamente.");
}

// Validación de entrada numérica que valide que la entrada sea numérica y que esté en un rango entre 1 y 10
function validarNumero() {
  let x = document.getElementById("numero").value;
  let texto;
  if (isNaN(x) || x < 1 || x > 10) {
    texto = "Entrada no válida";
  } else {
    texto = "Entrada correcta";
  }
  document.getElementById("demoNumero").innerHTML = texto;
  console.log("Resultado de la validación numérica:", texto);
}

// a) Cambiar el valor de un atributo src de un elemento <img>
document.getElementById('miImagen').src="/case.jpeg";

// a) Agregar la hora actual a una etiqueta con id="demo"
var clockTimeout;

function mostrarFechaHora() {
  const now = new Date();
  document.getElementById('clock').innerText = `Fecha y Hora: ${now.toLocaleString()}`;
  document.getElementById('clock').style.display = 'block';
  clearTimeout(clockTimeout);
  clockTimeout = setTimeout(ocultarReloj, 10000);
  console.log("Fecha y hora actual mostradas:", now);
}

function ocultarReloj() {
  document.getElementById('clock').style.display = 'none';
}
